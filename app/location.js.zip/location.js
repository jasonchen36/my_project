process.on('message',function(gdata){

	var fquery=[]

  titles=gdata.titles
  for (i in titles){
    fquery.push({"title":titles[i]})
  }

console.log(fquery)



var mongo = require('mongodb'),  
  Server = mongo.Server,
  Db = mongo.Db;
var server = new Server('localhost', 27017, {  
  auto_reconnect: true
});
var db = new Db('mongoo', server);  
var onErr = function(err, callback) {  
  db.close();
  callback(err);
};


getdata1 = function(dquery, callback) {  
  db.open(function(err, db) {
    if (!err) {
      db.collection('location', function(err, collection) {
        if (!err) {
          collection.find({$or:
            dquery
            }).toArray(function(err, docs) {
            if (!err) {
              db.close();
             // console.log('got data')
              callback(docs);
            } else {
              onErr(err, callback);
            }
          }); //end collection.find 
        } else {
          onErr(err, callback);
        }
      }); //end db.collection
    } else {
      onErr(err, callback);
    }
  }); // end db.open
};




getdata = function(dquery, callback) {  
  db.open(function(err, db) {
    if (!err) {
      db.collection('location', function(err, collection) {
        if (!err) {
          collection.find({$or:
            dquery[0]
            },dquery[1]).toArray(function(err, docs) {
            if (!err) {
              db.close();
             // console.log('got data')
              callback(docs);
            } else {
              onErr(err, callback);
            }
          }); //end collection.find 
        } else {
          onErr(err, callback);
        }
      }); //end db.collection
    } else {
      onErr(err, callback);
    }
  }); // end db.open
};

/*
getadata1 = function(fquery, callback) {  
  db.open(function(err, db) {
    if (!err) {
      db.collection('dmovies', function(err, collection) {
        if (!err) {
          collection.aggregate([{$match:{$and:fquery}}
                                    ,{$unwind:"$actors"}
                                    ,{$group:{_id:"$actors"
                                              ,number:{$sum:1}
                                              ,apsum:{$sum:'$ap'}}}
                                    ,{$sort:{number:-1}}
                                    ]
                                    ,function(err, docs) {
            if (!err) {
              db.close();
            //  console.log('got data')
              //console.log(docs)
              callback(docs);
            } else {
              onErr(err, callback);
            }
          }); //end collection.mapreduce 
        } else {
          onErr(err, callback);
        }
      }); //end db.collection
    } else {
      onErr(err, callback);
    }
  }); // end db.open
};


getadata = function(dquery, callback) {  
  db.open(function(err, db) {
    if (!err) {
      db.collection('dmovies', function(err, collection) {
        if (!err) {
          collection.aggregate([{$match:{$and:dquery}}
                                    ,{$unwind:"$actors"}
                                    ,{$group:{_id:"$actors"
                                              ,number:{$sum:1}
                                              }}
                                    ,{$sort:{number:-1}}
                                    ,{$limit:1000}]
                                    ,function(err, docs) {
            if (!err) {
              db.close();
            //  console.log('got data')
              //console.log(docs)
              callback(docs);
            } else {
              onErr(err, callback);
            }
          }); //end collection.mapreduce 
        } else {
          onErr(err, callback);
        }
      }); //end db.collection
    } else {
      onErr(err, callback);
    }
  }); // end db.open
};



finddata = function(dquery, callback) {  
  db.open(function(err, db) {
    if (!err) {
      db.collection('dmovies', function(err, collection) {
        if (!err) {
          collection.find({$and:
            dquery
            },{'_id':0,'__v':0}).toArray(function(err, docs) {
            if (!err) {
              db.close();
             // console.log('got data')
              callback(docs);
            } else {
              onErr(err, callback);
            }
          }); //end collection.find 
        } else {
          onErr(err, callback);
        }
      }); //end db.collection
    } else {
      onErr(err, callback);
    }
  }); // end db.open
};

                                        ////filter data and data1

                                        ///save filters to query

                                        ///var newQuery            = new Query();

                                                        // set the user's local credentials
                                        ///                newQuery.email    = email;
                                         ///               newQuery.save(function(err) {
                                          ///                  if (err)
                                          ///                      throw err;
                                           ///                 return done(null, newQuery);
                                           ///             });


finddata(dquery,function(data){
          finddata(fquery,function(data1){
                      getdata(dquery,function(odata){
                              getdata1(fquery,function(data1kw){




       




process.send({ddd:ddd,ddd1:ddd,dsdkw:fnumd,sdkw:fnumd,ktpercentage:fnum,
                                                      sum:summary,dsdactors:dsdactors,sdactors:sdactors,tpercentage:tpercentage,
                                                      asummary:asummary,dsddp:dsddp,sddp:sddp,dptpercentage:dptpercentage,
                                                      dpsummary:dpsummary})

	 })})})})

*/

getdata1(fquery,function(data1kw){
  //process.send({})


    var cutoff=[]
  for (i in data1kw){
    if (data1kw[i]['summary'].length <30){
      cutoff.push([i])
    }
  }

  for (i in cutoff){
    data1kw.splice(cutoff[i],1)
  }
 // console.log(cutoff)
  var data=[]

  for (i in data1kw){
    data.push(data1kw[i]['summary'])
  }



  var merged = [].concat.apply([], data)

//  console.log(merged.length)

function foo(arr) {
    var a = [], b = [], prev;
    
    arr.sort();
    for ( var i = 0; i < arr.length; i++ ) {
        if ( arr[i] !== prev ) {
            a.push(arr[i]);
            b.push(1);
        } else {
            b[b.length-1]++;
        }
        prev = arr[i];
    }
    
    return [a, b];
}

var result = foo(merged);

//console.log(result)
m=data1kw.length



check=[]
for (i in result[1]){
  if (result[1][i]==m){
 //   result[0].splice(i,1)

    check.push(result[0][i])

  }
}
a_title=[]
console.log(m)

//console.log(data1kw[2].title)

for (var i =0; i<m;i++){
  a_title.push(data1kw[i].title)
}

res_data={}
res_loc_data={}
aud_total=0


for (i in check) {
  aud_ratio_total=0
  dif_ratio_total=0
  dif_total=0
  city_name=check[i].replace(".","_")
  
  for (j in data1kw){
  //  console.log(data1kw[j])
  // console.log(city_name)
    aud_total+=data1kw[j][city_name]["aud_total"]
    aud_ratio_total+=data1kw[j][city_name]["aud_ratio"]
    dif_ratio_total+=data1kw[j][city_name]["dif_ratio"]
    dif_total+=data1kw[j][city_name]["dif"]
    //console.log(city_name)
    //console.log(aud_ratio_total)
  }
  avg_aud_ratio=Math.round(aud_ratio_total/m*10000)/10000
  avg_dif_ratio=Math.round(dif_ratio_total/m*10000)/10000
  avg_dif=Math.round(dif_total/m*10000)/10000
  
  res_loc_data[city_name]={"aud_ratio":avg_aud_ratio,"dif":avg_dif,"dif_ratio":avg_dif_ratio

  }

}

avg_aud=Math.round(aud_total/m*1)/1
res_aud_total=Math.round(aud_total*1)/1


res_data['location_data']=res_loc_data
res_data['avg_data']=avg_aud
res_data['aud_total']=m
res_data['a_title']=a_title

console.log(res_data['a_title'])

process.send({res_data:res_data})


})





})